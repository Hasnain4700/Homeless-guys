import Header from './components/Header'
import Slider from './components/Slider'
import GameShowcase from './components/GameShowcase'
import News from './components/News'
import Careers from './components/Careers'
import About from './components/About'
import Footer from './components/Footer'
import Newsletter from './components/Newsletter'
import TeamShowcase from './components/TeamShowcase'

export default function Home() {
  return (
    <div className="min-h-screen bg-gray-900 text-green-400 font-mono">
      <Header />
      <Slider />
      <main>
        <GameShowcase />
        <News />
        <TeamShowcase />
        <Careers />
        <About />
        <Newsletter />
      </main>
      <Footer />
    </div>
  )
}

