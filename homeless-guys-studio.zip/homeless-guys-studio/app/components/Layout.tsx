import { ReactNode } from 'react'
import Header from './Header'
import Footer from './Footer'
import Sidebar from './Sidebar'

type LayoutProps = {
  children: ReactNode
  sidebarPosition?: 'left' | 'right' | 'none'
  showHeader?: boolean
  showFooter?: boolean
}

export default function Layout({
  children,
  sidebarPosition = 'right',
  showHeader = true,
  showFooter = true
}: LayoutProps) {
  return (
    <div className="min-h-screen bg-gray-900 text-green-400 font-mono">
      {showHeader && <Header />}
      <div className="container mx-auto px-4 py-8">
        <div className={`flex flex-col ${sidebarPosition === 'left' ? 'md:flex-row-reverse' : 'md:flex-row'}`}>
          {sidebarPosition !== 'none' && (
            <aside className={`w-full md:w-1/3 ${sidebarPosition === 'left' ? 'md:mr-8' : 'md:ml-8'} mt-8 md:mt-0`}>
              <Sidebar />
            </aside>
          )}
          <main className={`w-full ${sidebarPosition !== 'none' ? 'md:w-2/3' : ''}`}>
            {children}
          </main>
        </div>
      </div>
      {showFooter && <Footer />}
    </div>
  )
}

