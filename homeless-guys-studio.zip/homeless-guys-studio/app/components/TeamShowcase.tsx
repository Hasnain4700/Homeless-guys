'use client'

import Image from 'next/image'
import { useState, useEffect } from 'react'
import { X } from 'lucide-react'

type TeamMember = {
  id: number
  name: string
  role: string
  image: string
  description: string
  skills: {
    [key: string]: number
  }
}

export default function TeamShowcase() {
  const [teamMembers, setTeamMembers] = useState<TeamMember[]>([
    { id: 1, name: 'Abis Syed', role: 'Jhenga', image: '/placeholder.svg', description: 'Jane is our brilliant lead developer with over 10 years of experience in game development.', skills: { 'C++': 95, 'Unity': 90, 'Game Design': 85 } },
    { id: 2, name: 'Ahmad Ajmal', role: 'Programmer', image: '/placeholder.svg', description: 'John brings our game worlds to life with his stunning visual designs and artistic direction.', skills: { '3D Modeling': 95, 'Concept Art': 90, 'Animation': 85 } },
    { id: 3, name: 'Hasnain Iqbal', role: 'Lead Developer', image: '/placeholder.svg', description: 'Alice crafts engaging gameplay mechanics and compelling narratives for our games.', skills: { 'Game Design': 95, 'Level Design': 90, 'Storytelling': 90 } },
    { id: 4, name: 'Haseeb ur Rehman', role: 'Game Designer', image: '/placeholder.svg', description: 'Bob creates immersive soundscapes and music that bring depth to our game worlds.', skills: { 'Sound Design': 95, 'Music Composition': 90, 'Audio Programming': 85 } },
    { id: 5, name: 'Kims', role: '3d Modeler', image: '/placeholder.svg', description: 'Kims ensures the quality and polish of our games through rigorous testing and feedback.', skills: { 'Bug Testing': 95, 'User Experience': 90, 'Project Management': 85 } },
  ]);

  const [selectedMember, setSelectedMember] = useState<TeamMember | null>(null);

  useEffect(() => {
    const savedTeamMembers = localStorage.getItem('teamMembers');
    if (savedTeamMembers) {
      setTeamMembers(JSON.parse(savedTeamMembers));
    }
  }, []);

  const openPopup = (member: TeamMember) => {
    setSelectedMember(member);
  };

  const closePopup = () => {
    setSelectedMember(null);
  };

  return (
    <section id="team" className="py-20 bg-gray-800">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">Our Team</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8">
          {teamMembers.map((member) => (
            <div 
              key={member.id} 
              className="bg-gray-900 rounded-lg overflow-hidden shadow-lg cursor-pointer transition-transform hover:scale-105"
              onClick={() => openPopup(member)}
            >
              <Image 
                src={member.image} 
                alt={member.name} 
                width={300} 
                height={300} 
                className="w-full h-64 object-cover"
              />
              <div className="p-4">
                <h3 className="text-xl font-bold mb-1">{member.name}</h3>
                <p className="text-green-500">{member.role}</p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {selectedMember && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-8 rounded-lg max-w-2xl w-full relative">
            <button
              onClick={closePopup}
              className="absolute top-2 right-2 text-gray-400 hover:text-white"
            >
              <X size={24} />
            </button>
            <div className="flex items-center mb-6">
              <Image 
                src={selectedMember.image} 
                alt={selectedMember.name} 
                width={100} 
                height={100} 
                className="rounded-full mr-4"
              />
              <div>
                <h3 className="text-2xl font-bold">{selectedMember.name}</h3>
                <p className="text-green-500">{selectedMember.role}</p>
              </div>
            </div>
            <p className="mb-6">{selectedMember.description}</p>
            <h4 className="text-xl font-bold mb-4">Skills</h4>
            <div className="space-y-4">
              {Object.entries(selectedMember.skills).map(([skill, level]) => (
                <div key={skill}>
                  <div className="flex justify-between mb-1">
                    <span>{skill}</span>
                    <span>{level}%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2.5">
                    <div 
                      className="bg-green-500 h-2.5 rounded-full" 
                      style={{ width: `${level}%` }}
                    ></div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </section>
  )
}

