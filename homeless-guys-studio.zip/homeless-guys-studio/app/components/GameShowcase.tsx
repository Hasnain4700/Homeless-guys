'use client'

import { useState } from 'react'
import Image from 'next/image'
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from "@/components/ui/dialog"

const games = [
  { id: 1, title: 'The Hountel', image: '/placeholder.svg', description: 'A new experience of horror and simulation genres.' },
  { id: 2, title: 'Chicken Simulator', image: '/placeholder.svg', description: 'The Story Of Hen.' },
  { id: 3, title: 'Multiplayer Project', image: '/placeholder.svg', description: 'Currently Closed.' },
]

export default function GameShowcase() {
  const [selectedGame, setSelectedGame] = useState(null)

  return (
    <section id="games" className="py-20 bg-gray-800">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">Our Games</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {games.map((game) => (
            <div key={game.id} className="group relative overflow-hidden rounded-lg shadow-lg cursor-pointer" onClick={() => setSelectedGame(game)}>
              <Image 
                src={game.image} 
                alt={game.title} 
                width={400} 
                height={225} 
                className="w-full transition-transform duration-300 group-hover:scale-110"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-end">
                <h3 className="text-white text-2xl font-bold p-4">{game.title}</h3>
              </div>
            </div>
          ))}
        </div>
      </div>
      <Dialog open={!!selectedGame} onOpenChange={() => setSelectedGame(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>{selectedGame?.title}</DialogTitle>
            <DialogDescription>{selectedGame?.description}</DialogDescription>
          </DialogHeader>
          {selectedGame && (
            <Image 
              src={selectedGame.image} 
              alt={selectedGame.title} 
              width={600} 
              height={338} 
              className="w-full rounded-lg"
            />
          )}
        </DialogContent>
      </Dialog>
    </section>
  )
}

