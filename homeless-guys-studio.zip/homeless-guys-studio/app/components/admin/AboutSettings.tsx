'use client'

import { useState } from 'react'

const initialAbout = {
  content: `Homeless Guys Studio is an unconventional game development studio born from the streets, 
specializing in creating immersive, gritty gaming experiences that reflect real-world struggles. 
Our team of passionate developers, artists, and designers work tirelessly to push the boundaries 
of storytelling in interactive entertainment.

Founded in 2010 by a group of talented but down-on-their-luck developers, we've consistently 
delivered groundbreaking titles that blend innovative gameplay mechanics with raw, authentic 
narratives. At Homeless Guys Studio, we believe in the power of games to shed light on social 
issues and bring people together through shared experiences.

Our unique perspective and diverse team allow us to create games that not only entertain but 
also challenge players to think differently about the world around them. Join us on our mission 
to change the gaming industry, one pixel at a time.`
}

export default function AboutSettings() {
  const [about, setAbout] = useState(initialAbout)

  const handleContentChange = (value: string) => {
    setAbout({ ...about, content: value })
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">About Settings</h2>
      <div className="mb-8 p-4 bg-gray-800 rounded-lg">
        <label className="block mb-2">Content</label>
        <textarea
          value={about.content}
          onChange={(e) => handleContentChange(e.target.value)}
          className="w-full p-2 bg-gray-700 rounded"
          rows={10}
        />
      </div>
    </div>
  )
}

