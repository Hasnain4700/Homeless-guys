'use client'

import { useState, useEffect } from 'react'

type TeamMember = {
  id: number
  name: string
  role: string
  image: string
  description: string
  skills: {
    [key: string]: number
  }
}

const initialTeamMembers: TeamMember[] = [
  { id: 1, name: 'Jane Doe', role: 'Lead Developer', image: '/placeholder.svg', description: 'Jane is our brilliant lead developer with over 10 years of experience in game development.', skills: { 'C++': 95, 'Unity': 90, 'Game Design': 85 } },
  { id: 2, name: 'John Smith', role: 'Art Director', image: '/placeholder.svg', description: 'John brings our game worlds to life with his stunning visual designs and artistic direction.', skills: { '3D Modeling': 95, 'Concept Art': 90, 'Animation': 85 } },
  { id: 3, name: 'Alice Johnson', role: 'Game Designer', image: '/placeholder.svg', description: 'Alice crafts engaging gameplay mechanics and compelling narratives for our games.', skills: { 'Game Design': 95, 'Level Design': 90, 'Storytelling': 90 } },
  { id: 4, name: 'Bob Williams', role: 'Sound Engineer', image: '/placeholder.svg', description: 'Bob creates immersive soundscapes and music that bring depth to our game worlds.', skills: { 'Sound Design': 95, 'Music Composition': 90, 'Audio Programming': 85 } },
  { id: 5, name: 'Eva Martinez', role: 'QA Lead', image: '/placeholder.svg', description: 'Eva ensures the quality and polish of our games through rigorous testing and feedback.', skills: { 'Bug Testing': 95, 'User Experience': 90, 'Project Management': 85 } },
]

export default function TeamSettings() {
  const [teamMembers, setTeamMembers] = useState(initialTeamMembers)

  useEffect(() => {
    const savedTeamMembers = localStorage.getItem('teamMembers');
    if (savedTeamMembers) {
      setTeamMembers(JSON.parse(savedTeamMembers));
    }

    const handleSaveChanges = () => {
      localStorage.setItem('teamMembers', JSON.stringify(teamMembers));
    };

    window.addEventListener('saveChanges', handleSaveChanges);

    return () => {
      window.removeEventListener('saveChanges', handleSaveChanges);
    };
  }, [teamMembers]);

  const handleMemberChange = (id: number, field: string, value: string | number) => {
    setTeamMembers(prevMembers => prevMembers.map(member =>
      member.id === id ? { ...member, [field]: value } : member
    ))
  }

  const handleSkillChange = (id: number, skill: string, value: number) => {
    setTeamMembers(prevMembers => prevMembers.map(member =>
      member.id === id ? { ...member, skills: { ...member.skills, [skill]: value } } : member
    ))
  }

  const addSkill = (id: number) => {
    setTeamMembers(prevMembers => prevMembers.map(member =>
      member.id === id ? { ...member, skills: { ...member.skills, 'New Skill': 50 } } : member
    ))
  }

  const removeSkill = (id: number, skillToRemove: string) => {
    setTeamMembers(prevMembers => prevMembers.map(member => {
      if (member.id === id) {
        const { [skillToRemove]: _, ...remainingSkills } = member.skills;
        return { ...member, skills: remainingSkills };
      }
      return member;
    }))
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Team Settings</h2>
      {teamMembers.map(member => (
        <div key={member.id} className="mb-8 p-4 bg-gray-800 rounded-lg">
          <h3 className="text-xl font-bold mb-2">Team Member {member.id}</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-2">Name</label>
              <input
                type="text"
                value={member.name}
                onChange={(e) => handleMemberChange(member.id, 'name', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div>
              <label className="block mb-2">Role</label>
              <input
                type="text"
                value={member.role}
                onChange={(e) => handleMemberChange(member.id, 'role', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div>
              <label className="block mb-2">Image URL</label>
              <input
                type="text"
                value={member.image}
                onChange={(e) => handleMemberChange(member.id, 'image', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div className="col-span-2">
              <label className="block mb-2">Description</label>
              <textarea
                value={member.description}
                onChange={(e) => handleMemberChange(member.id, 'description', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
                rows={3}
              />
            </div>
            <div className="col-span-2">
              <h4 className="text-lg font-bold mb-2">Skills</h4>
              {Object.entries(member.skills).map(([skill, level]) => (
                <div key={skill} className="flex items-center mb-2">
                  <input
                    type="text"
                    value={skill}
                    onChange={(e) => {
                      const newSkill = e.target.value;
                      setTeamMembers(prevMembers => prevMembers.map(m => {
                        if (m.id === member.id) {
                          const { [skill]: oldSkill, ...rest } = m.skills;
                          return { ...m, skills: { ...rest, [newSkill]: oldSkill } };
                        }
                        return m;
                      }))
                    }}
                    className="w-1/3 p-2 bg-gray-700 rounded mr-2"
                  />
                  <input
                    type="number"
                    value={level}
                    onChange={(e) => handleSkillChange(member.id, skill, Number(e.target.value))}
                    className="w-1/3 p-2 bg-gray-700 rounded mr-2"
                    min="0"
                    max="100"
                  />
                  <button
                    onClick={() => removeSkill(member.id, skill)}
                    className="bg-red-500 text-white px-2 py-1 rounded hover:bg-red-600 transition-colors"
                  >
                    Remove
                  </button>
                </div>
              ))}
              <button
                onClick={() => addSkill(member.id)}
                className="bg-green-500 text-white px-4 py-2 rounded hover:bg-green-600 transition-colors mt-2"
              >
                Add Skill
              </button>
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

