'use client'

import { useState } from 'react'

const initialNewsItems = [
  { id: 1, title: 'CyberNexus 2.0 Update Released', date: '2023-06-15', excerpt: 'Experience the new neon-drenched district and face off against the mysterious AI collective.' },
  { id: 2, title: 'Quantum Break Wins Game of the Year', date: '2023-05-22', excerpt: 'Our time-bending adventure has been recognized as the top game of 2023!' },
  { id: 3, title: 'Neural Override Open Beta Announced', date: '2023-04-10', excerpt: 'Sign up now to be among the first to test our upcoming mind-hacking thriller.' },
]

export default function NewsSettings() {
  const [newsItems, setNewsItems] = useState(initialNewsItems)

  const handleNewsChange = (id: number, field: string, value: string) => {
    setNewsItems(newsItems.map(item => 
      item.id === id ? { ...item, [field]: value } : item
    ))
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">News Settings</h2>
      {newsItems.map(item => (
        <div key={item.id} className="mb-8 p-4 bg-gray-800 rounded-lg">
          <h3 className="text-xl font-bold mb-2">News Item {item.id}</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-2">Title</label>
              <input
                type="text"
                value={item.title}
                onChange={(e) => handleNewsChange(item.id, 'title', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div>
              <label className="block mb-2">Date</label>
              <input
                type="text"
                value={item.date}
                onChange={(e) => handleNewsChange(item.id, 'date', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div className="col-span-2">
              <label className="block mb-2">Excerpt</label>
              <textarea
                value={item.excerpt}
                onChange={(e) => handleNewsChange(item.id, 'excerpt', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
                rows={3}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

