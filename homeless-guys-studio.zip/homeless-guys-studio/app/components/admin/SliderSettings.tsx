'use client'

import { useState, useEffect } from 'react'

const initialSlides = [
  { id: 1, image: '/placeholder.svg', title: 'CyberNexus', description: 'Enter the digital realm', color: 'from-blue-500 to-purple-500' },
  { id: 2, image: '/placeholder.svg', title: 'Quantum Break', description: 'Bend time to your will', color: 'from-red-500 to-yellow-500' },
  { id: 3, image: '/placeholder.svg', title: 'Neural Override', description: 'Hack into the future', color: 'from-green-500 to-teal-500' },
]

export default function SliderSettings() {
  const [slides, setSlides] = useState(initialSlides)

  useEffect(() => {
    const savedSlides = localStorage.getItem('slides');
    if (savedSlides) {
      setSlides(JSON.parse(savedSlides));
    }
  }, []);

  useEffect(() => {
    const handleSaveChanges = () => {
      localStorage.setItem('slides', JSON.stringify(slides));
    };

    window.addEventListener('saveChanges', handleSaveChanges);

    return () => {
      window.removeEventListener('saveChanges', handleSaveChanges);
    };
  }, [slides]);

  const handleSlideChange = (id: number, field: string, value: string) => {
    setSlides(prevSlides => prevSlides.map(slide => 
      slide.id === id ? { ...slide, [field]: value } : slide
    ))
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Slider Settings</h2>
      {slides.map(slide => (
        <div key={slide.id} className="mb-8 p-4 bg-gray-800 rounded-lg">
          <h3 className="text-xl font-bold mb-2">Slide {slide.id}</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-2">Title</label>
              <input
                type="text"
                value={slide.title}
                onChange={(e) => handleSlideChange(slide.id, 'title', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div>
              <label className="block mb-2">Description</label>
              <input
                type="text"
                value={slide.description}
                onChange={(e) => handleSlideChange(slide.id, 'description', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div>
              <label className="block mb-2">Image URL</label>
              <input
                type="text"
                value={slide.image}
                onChange={(e) => handleSlideChange(slide.id, 'image', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div>
              <label className="block mb-2">Color Gradient</label>
              <input
                type="text"
                value={slide.color}
                onChange={(e) => handleSlideChange(slide.id, 'color', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

