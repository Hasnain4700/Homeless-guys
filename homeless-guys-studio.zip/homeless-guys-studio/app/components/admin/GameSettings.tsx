'use client'

import { useState } from 'react'

const initialGames = [
  { id: 1, title: 'CyberNexus', image: '/placeholder.svg', description: 'A cyberpunk adventure set in a dystopian future.' },
  { id: 2, title: 'Quantum Break', image: '/placeholder.svg', description: 'Manipulate time in this mind-bending puzzle platformer.' },
  { id: 3, title: 'Neural Override', image: '/placeholder.svg', description: 'Hack into the minds of your enemies in this stealth action game.' },
]

export default function GameSettings() {
  const [games, setGames] = useState(initialGames)

  const handleGameChange = (id: number, field: string, value: string) => {
    setGames(games.map(game => 
      game.id === id ? { ...game, [field]: value } : game
    ))
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Game Settings</h2>
      {games.map(game => (
        <div key={game.id} className="mb-8 p-4 bg-gray-800 rounded-lg">
          <h3 className="text-xl font-bold mb-2">Game {game.id}</h3>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block mb-2">Title</label>
              <input
                type="text"
                value={game.title}
                onChange={(e) => handleGameChange(game.id, 'title', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div>
              <label className="block mb-2">Image URL</label>
              <input
                type="text"
                value={game.image}
                onChange={(e) => handleGameChange(game.id, 'image', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
              />
            </div>
            <div className="col-span-2">
              <label className="block mb-2">Description</label>
              <textarea
                value={game.description}
                onChange={(e) => handleGameChange(game.id, 'description', e.target.value)}
                className="w-full p-2 bg-gray-700 rounded"
                rows={3}
              />
            </div>
          </div>
        </div>
      ))}
    </div>
  )
}

