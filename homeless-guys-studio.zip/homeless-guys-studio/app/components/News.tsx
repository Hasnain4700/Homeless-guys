import { ArrowRight } from 'lucide-react'

const newsItems = [
  { id: 1, title: 'The Hountel Update#', date: '2023-06-15', excerpt: 'We are working on this project will share the demo trailer soon..' },
  { id: 2, title: 'Quantum Break Wins Game of the Year', date: '2023-05-22', excerpt: 'Our time-bending adventure has been recognized as the top game of 2023!' },
  { id: 3, title: 'Neural Override Open Beta Announced', date: '2023-04-10', excerpt: 'Sign up now to be among the first to test our upcoming mind-hacking thriller.' },
]

export default function News() {
  return (
    <section id="news" className="py-20 bg-gray-900">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">Latest News</h2>
        <div className="space-y-8">
          {newsItems.map((item) => (
            <div key={item.id} className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition-colors">
              <h3 className="text-2xl font-bold mb-2">{item.title}</h3>
              <p className="text-gray-400 mb-4">{item.date}</p>
              <p className="mb-4">{item.excerpt}</p>
              <a href="#" className="inline-flex items-center text-green-500 hover:text-green-400 transition-colors">
                Read More <ArrowRight className="ml-2" />
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}

