'use client'

import { useState, useEffect } from 'react'

export default function AnimatedLogo() {
  const [text, setText] = useState('HomelessGuys')
  const [cursorVisible, setCursorVisible] = useState(true)

  useEffect(() => {
    const interval = setInterval(() => {
      setText(prevText => {
        if (prevText === 'HomelessGuys') return 'HomelessGuys{'
        if (prevText === 'HomelessGuys{') return 'HomelessGuys{}'
        return 'HomelessGuys'
      })
    }, 500)

    const cursorInterval = setInterval(() => {
      setCursorVisible(prev => !prev)
    }, 400)

    return () => {
      clearInterval(interval)
      clearInterval(cursorInterval)
    }
  }, [])

  return (
    <div className="font-mono text-2xl font-bold">
      <span className="text-white">{text}</span>
      <span className={`${cursorVisible ? 'opacity-100' : 'opacity-0'} transition-opacity duration-100`}>|</span>
      <span className="text-green-500">Studio</span>
    </div>
  )
}

