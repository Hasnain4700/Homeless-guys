'use client'

import Link from 'next/link'
import { useRouter } from 'next/navigation'

export default function AdminHeader() {
  const router = useRouter()

  const handleLogout = () => {
    localStorage.removeItem('isLoggedIn')
    router.push('/admin/login')
  }

  return (
    <header className="bg-black p-4">
      <nav className="container mx-auto flex justify-between items-center">
        <Link href="/admin" className="text-2xl font-bold">
          Homeless<span className="text-green-500">Guys</span>Studio Admin
        </Link>
        <div>
          <Link href="/" className="text-green-500 hover:text-green-400 transition-colors mr-4">
            Back to Site
          </Link>
          <button
            onClick={handleLogout}
            className="text-red-500 hover:text-red-400 transition-colors"
          >
            Logout
          </button>
        </div>
      </nav>
    </header>
  )
}

