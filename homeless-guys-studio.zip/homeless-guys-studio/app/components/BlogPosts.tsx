import Link from 'next/link'

const posts = [
  { id: 1, title: 'My Life on the Streets', date: '2023-06-15', excerpt: 'A day in the life of a homeless game developer...' },
  { id: 2, title: 'Coding from the Park Bench', date: '2023-05-22', excerpt: 'How I manage to code without a proper setup...' },
  { id: 3, title: 'The Kindness of Strangers', date: '2023-04-10', excerpt: 'Stories of unexpected help and inspiration...' },
]

export default function BlogPosts() {
  return (
    <div className="space-y-8">
      {posts.map((post) => (
        <article key={post.id} className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition-colors">
          <h2 className="text-2xl font-bold mb-2">
            <Link href={`/post/${post.id}`} className="hover:text-green-300 transition-colors">
              {post.title}
            </Link>
          </h2>
          <p className="text-gray-400 mb-4">{post.date}</p>
          <p className="mb-4">{post.excerpt}</p>
          <Link href={`/post/${post.id}`} className="text-green-500 hover:text-green-400 transition-colors">
            Read More
          </Link>
        </article>
      ))}
    </div>
  )
}

