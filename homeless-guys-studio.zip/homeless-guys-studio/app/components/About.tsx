export default function About() {
  return (
    <section id="about" className="py-20 bg-gray-800">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">About Homeless Guys Studio</h2>
        <div className="bg-gray-900 p-8 rounded-lg shadow-lg">
          <p className="text-lg mb-6">
            Homeless Guys Studio is an unconventional game development studio born from the streets, 
            specializing in creating immersive, gritty gaming experiences that reflect real-world struggles. 
            Our team of passionate developers, artists, and designers work tirelessly to push the boundaries 
            of storytelling in interactive entertainment.
          </p>
          <p className="text-lg mb-6">
            Founded in 2010 by a group of talented but down-on-their-luck developers, we've consistently 
            delivered groundbreaking titles that blend innovative gameplay mechanics with raw, authentic 
            narratives. At Homeless Guys Studio, we believe in the power of games to shed light on social 
            issues and bring people together through shared experiences.
          </p>
          <p className="text-lg">
            Our unique perspective and diverse team allow us to create games that not only entertain but 
            also challenge players to think differently about the world around them. Join us on our mission 
            to change the gaming industry, one pixel at a time.
          </p>
        </div>
      </div>
    </section>
  )
}

