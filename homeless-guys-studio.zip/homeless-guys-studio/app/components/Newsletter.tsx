'use client'

import { useState } from 'react'

export default function Newsletter() {
  const [email, setEmail] = useState('')

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Here you would typically send the email to your server
    console.log('Submitted email:', email)
    setEmail('')
    alert('Thank you for subscribing!')
  }

  return (
    <section className="py-20 bg-gray-900">
      <div className="container mx-auto px-4">
        <h2 className="text-4xl font-bold mb-8 text-center">Stay Updated</h2>
        <p className="text-xl mb-8 text-center">Subscribe to our newsletter for the latest news and game releases.</p>
        <form onSubmit={handleSubmit} className="max-w-md mx-auto">
          <div className="flex">
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="Enter your email"
              required
              className="flex-grow px-4 py-2 rounded-l-lg focus:outline-none focus:ring-2 focus:ring-green-500 bg-gray-800 text-white"
            />
            <button
              type="submit"
              className="bg-green-500 text-white px-6 py-2 rounded-r-lg hover:bg-green-600 transition-colors"
            >
              Subscribe
            </button>
          </div>
        </form>
      </div>
    </section>
  )
}

