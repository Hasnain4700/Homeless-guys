'use client'

import { useState, useEffect } from 'react'
import Image from 'next/image'
import { ChevronLeft, ChevronRight } from 'lucide-react'

export default function Slider() {
  const [slides, setSlides] = useState([
    { id: 1, image: '/placeholder.svg', title: 'The Hountel', description: 'A new experience of horror and simulation genres', color: 'from-blue-500 to-purple-500' },
    { id: 2, image: '/placeholder.svg', title: 'Chicken Simulator', description: 'The story of Hen', color: 'from-red-500 to-yellow-500' },
    { id: 3, image: '/placeholder.svg', title: 'Multiplayer Project', description: 'Currently closed', color: 'from-green-500 to-teal-500' },
  ]);

  const [currentSlide, setCurrentSlide] = useState(0)

  useEffect(() => {
    const savedSlides = localStorage.getItem('slides');
    if (savedSlides) {
      setSlides(JSON.parse(savedSlides));
    }
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prevSlide) => (prevSlide + 1) % slides.length)
    }, 5000)
    return () => clearInterval(timer)
  }, [slides.length])

  const goToSlide = (index: number) => {
    setCurrentSlide(index)
  }

  const goToPrevSlide = () => {
    setCurrentSlide((prevSlide) => (prevSlide - 1 + slides.length) % slides.length)
  }

  const goToNextSlide = () => {
    setCurrentSlide((prevSlide) => (prevSlide + 1) % slides.length)
  }

  return (
    <div className="relative h-[600px] overflow-hidden">
      {slides.map((slide, index) => (
        <div
          key={slide.id}
          className={`absolute top-0 left-0 w-full h-full transition-opacity duration-1000 ${
            index === currentSlide ? 'opacity-100' : 'opacity-0'
          }`}
        >
          <Image
            src={slide.image}
            alt={slide.title}
            layout="fill"
            objectFit="cover"
            priority
          />
          <div className={`absolute inset-0 bg-gradient-to-r ${slide.color} opacity-75`}></div>
          <div className="absolute inset-0 flex items-center justify-center">
            <div className="text-center">
              <h2 className="text-5xl font-bold mb-4 text-white">{slide.title}</h2>
              <p className="text-xl mb-8 text-white">{slide.description}</p>
              <button className="bg-white text-gray-900 py-2 px-6 rounded-full hover:bg-gray-200 transition-colors">
                Learn More
              </button>
            </div>
          </div>
        </div>
      ))}
      <button
        className="absolute top-1/2 left-4 transform -translate-y-1/2 bg-black bg-opacity-50 p-2 rounded-full"
        onClick={goToPrevSlide}
      >
        <ChevronLeft className="text-white" />
      </button>
      <button
        className="absolute top-1/2 right-4 transform -translate-y-1/2 bg-black bg-opacity-50 p-2 rounded-full"
        onClick={goToNextSlide}
      >
        <ChevronRight className="text-white" />
      </button>
      <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
        {slides.map((_, index) => (
          <button
            key={index}
            className={`w-3 h-3 rounded-full ${
              index === currentSlide ? 'bg-white' : 'bg-white bg-opacity-50'
            }`}
            onClick={() => goToSlide(index)}
          />
        ))}
      </div>
    </div>
  )
}

