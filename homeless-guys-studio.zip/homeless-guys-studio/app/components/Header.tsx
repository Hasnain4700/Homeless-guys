'use client'

import { useState } from 'react'
import Link from 'next/link'
import { Menu, X } from 'lucide-react'
import AnimatedLogo from './AnimatedLogo'

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="bg-black p-4 sticky top-0 z-50">
      <nav className="container mx-auto flex justify-between items-center">
        <AnimatedLogo />
        <div className="hidden md:flex space-x-6">
          <Link href="#games" className="hover:text-green-300 transition-colors">Games</Link>
          <Link href="#news" className="hover:text-green-300 transition-colors">News</Link>
          <Link href="#team" className="hover:text-green-300 transition-colors">Team</Link>
          <Link href="#careers" className="hover:text-green-300 transition-colors">Careers</Link>
          <Link href="#about" className="hover:text-green-300 transition-colors">About</Link>
        </div>
        <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
          {isMenuOpen ? <X /> : <Menu />}
        </button>
      </nav>
      {isMenuOpen && (
        <div className="md:hidden bg-gray-800 mt-2">
          <Link href="#games" className="block p-2 hover:bg-gray-700">Games</Link>
          <Link href="#news" className="block p-2 hover:bg-gray-700">News</Link>
          <Link href="#team" className="block p-2 hover:bg-gray-700">Team</Link>
          <Link href="#careers" className="block p-2 hover:bg-gray-700">Careers</Link>
          <Link href="#about" className="block p-2 hover:bg-gray-700">About</Link>
        </div>
      )}
    </header>
  )
}

