'use client'

import { useState } from 'react'
import { ArrowRight, X } from 'lucide-react'

const jobs = [
  { id: 1, title: 'Senior Game Developer', location: 'Remote', description: 'Join our team to create cutting-edge game experiences.' },
  { id: 2, title: '3D Artist', location: 'New York, NY', description: 'Help bring our game worlds to life with stunning visuals.' },
  { id: 3, title: 'Game Designer', location: 'San Francisco, CA', description: 'Design innovative gameplay mechanics and compelling narratives.' },
]

export default function Careers() {
  const [isPopupOpen, setIsPopupOpen] = useState(false)

  const openPopup = () => setIsPopupOpen(true)
  const closePopup = () => setIsPopupOpen(false)

  return (
    <section id="careers" className="py-20 bg-gray-900 relative">
      <div className="container mx-auto">
        <h2 className="text-4xl font-bold mb-12 text-center">Join Our Team</h2>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {jobs.map((job) => (
            <div key={job.id} className="bg-gray-800 p-6 rounded-lg hover:bg-gray-700 transition-colors">
              <h3 className="text-2xl font-bold mb-2">{job.title}</h3>
              <p className="text-gray-400 mb-4">{job.location}</p>
              <p className="mb-4">{job.description}</p>
              <button 
                onClick={openPopup}
                className="inline-flex items-center text-green-500 hover:text-green-400 transition-colors"
              >
                Apply Now <ArrowRight className="ml-2" />
              </button>
            </div>
          ))}
        </div>
      </div>

      {isPopupOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-gray-800 p-8 rounded-lg max-w-md w-full relative">
            <h3 className="text-2xl font-bold mb-4">Oops! 404 Job Not Found</h3>
            <p className="mb-6">We are currently homeless and there is no job for you. But hey, at least we're all in the same boat! 🏠🚫🛶</p>
            <button
              onClick={closePopup}
              className="bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600 transition-colors"
            >
              OK, I'll code from the park bench
            </button>
            <button
              onClick={closePopup}
              className="absolute top-2 right-2 text-gray-400 hover:text-white"
            >
              <X size={24} />
            </button>
          </div>
        </div>
      )}
    </section>
  )
}

