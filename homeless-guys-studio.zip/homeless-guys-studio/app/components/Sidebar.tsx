import Link from 'next/link'

export default function Sidebar() {
  return (
    <div className="bg-gray-800 p-6 rounded-lg">
      <h2 className="text-2xl font-bold mb-4">About Me</h2>
      <p className="mb-4">A homeless game developer sharing my journey and experiences through this blog.</p>
      <h3 className="text-xl font-bold mb-2">Categories</h3>
      <ul className="space-y-2 mb-4">
        <li><Link href="/category/life-on-streets" className="hover:text-green-300 transition-colors">Life on the Streets</Link></li>
        <li><Link href="/category/game-dev" className="hover:text-green-300 transition-colors">Game Development</Link></li>
        <li><Link href="/category/inspiration" className="hover:text-green-300 transition-colors">Inspiration</Link></li>
      </ul>
      <h3 className="text-xl font-bold mb-2">Recent Posts</h3>
      <ul className="space-y-2">
        <li><Link href="/post/1" className="hover:text-green-300 transition-colors">My Life on the Streets</Link></li>
        <li><Link href="/post/2" className="hover:text-green-300 transition-colors">Coding from the Park Bench</Link></li>
        <li><Link href="/post/3" className="hover:text-green-300 transition-colors">The Kindness of Strangers</Link></li>
      </ul>
    </div>
  )
}

