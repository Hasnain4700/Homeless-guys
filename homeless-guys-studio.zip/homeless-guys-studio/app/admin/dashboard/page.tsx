'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import AdminHeader from '../../components/AdminHeader'
import SliderSettings from '../../components/admin/SliderSettings'
import TeamSettings from '../../components/admin/TeamSettings'
import NewsSettings from '../../components/admin/NewsSettings'
import AboutSettings from '../../components/admin/AboutSettings'
import GameSettings from '../../components/admin/GameSettings'

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState('slider')
  const [isLoading, setIsLoading] = useState(true)
  const router = useRouter()

  useEffect(() => {
    const isLoggedIn = localStorage.getItem('isLoggedIn')
    if (isLoggedIn !== 'true') {
      router.push('/admin/login')
    } else {
      setIsLoading(false)
    }
  }, [router])

  if (isLoading) {
    return <div className="min-h-screen bg-gray-900 text-green-400 font-mono flex items-center justify-center">Loading...</div>
  }

  return (
    <div className="min-h-screen bg-gray-900 text-green-400 font-mono">
      <AdminHeader />
      <main className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold mb-8">Admin Dashboard</h1>
        <div className="flex mb-8">
          <button
            className={`mr-4 px-4 py-2 rounded ${activeTab === 'slider' ? 'bg-green-500 text-white' : 'bg-gray-800'}`}
            onClick={() => setActiveTab('slider')}
          >
            Slider
          </button>
          <button
            className={`mr-4 px-4 py-2 rounded ${activeTab === 'team' ? 'bg-green-500 text-white' : 'bg-gray-800'}`}
            onClick={() => setActiveTab('team')}
          >
            Team
          </button>
          <button
            className={`mr-4 px-4 py-2 rounded ${activeTab === 'news' ? 'bg-green-500 text-white' : 'bg-gray-800'}`}
            onClick={() => setActiveTab('news')}
          >
            News
          </button>
          <button
            className={`mr-4 px-4 py-2 rounded ${activeTab === 'about' ? 'bg-green-500 text-white' : 'bg-gray-800'}`}
            onClick={() => setActiveTab('about')}
          >
            About
          </button>
          <button
            className={`mr-4 px-4 py-2 rounded ${activeTab === 'games' ? 'bg-green-500 text-white' : 'bg-gray-800'}`}
            onClick={() => setActiveTab('games')}
          >
            Games
          </button>
        </div>
        {activeTab === 'slider' && <SliderSettings />}
        {activeTab === 'team' && <TeamSettings />}
        {activeTab === 'news' && <NewsSettings />}
        {activeTab === 'about' && <AboutSettings />}
        {activeTab === 'games' && <GameSettings />}
        <button
          onClick={() => {
            // Save all changes to local storage
            const event = new Event('saveChanges');
            window.dispatchEvent(event);
            alert('Changes saved successfully!');
          }}
          className="mt-8 bg-green-500 text-white px-6 py-2 rounded hover:bg-green-600 transition-colors"
        >
          Save All Changes
        </button>
      </main>
    </div>
  )
}

