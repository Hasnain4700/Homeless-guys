import { notFound } from 'next/navigation'
import Layout from '../../components/Layout'

const posts = [
  { id: 1, title: 'My Life on the Streets', date: '2023-06-15', content: 'This is the full content of the blog post...' },
  { id: 2, title: 'Coding from the Park Bench', date: '2023-05-22', content: 'This is the full content of the blog post...' },
  { id: 3, title: 'The Kindness of Strangers', date: '2023-04-10', content: 'This is the full content of the blog post...' },
]

export default function BlogPost({ params }: { params: { id: string } }) {
  const post = posts.find(p => p.id === parseInt(params.id))

  if (!post) {
    notFound()
  }

  return (
    <Layout>
      <article className="bg-gray-800 p-6 rounded-lg">
        <h1 className="text-4xl font-bold mb-4">{post.title}</h1>
        <p className="text-gray-400 mb-8">{post.date}</p>
        <div className="prose prose-invert max-w-none">
          {post.content}
        </div>
      </article>
    </Layout>
  )
}

